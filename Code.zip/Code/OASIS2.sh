#! usr/bin/bash

<<comment
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Script for downloading OASIS-2 Dataset
comment

# Download Data
echo "Downloading OASIS-2 Data"
wget https://download.nrg.wustl.edu/data/OAS2_RAW_PART1.tar.gz
wget https://download.nrg.wustl.edu/data/OAS2_RAW_PART2.tar.gz
echo "Downloading Complete"

# Unzip Downloads
tar -xvzf OAS2_RAW_PART1.tar.gz
tar -xvzf OAS2_RAW_PART2.tar.gz

# Merge Directories
echo "Merging Directories"
rsync -avh --progress ./OAS2_RAW_PART1/ ./OAS2_RAW_PART2/

# Clean-Up
mv ./OAS2_RAW_PART2/ ./Data/
rm -rf ./OAS2_RAW_PART1/

echo "Complete!"
echo "Dataset located at ./Data"
