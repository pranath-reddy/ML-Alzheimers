#! usr/bin/bash

<<comment
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Script for downloading OASIS-1 Dataset
comment

# Download Data
echo "Downloading OASIS-1 Data"
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc1.tar.gz
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc2.tar.gz
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc3.tar.gz
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc4.tar.gz
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc5.tar.gz
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc6.tar.gz
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc7.tar.gz
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc8.tar.gz
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc9.tar.gz
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc10.tar.gz
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc11.tar.gz
wget https://download.nrg.wustl.edu/data/oasis_cross-sectional_disc12.tar.gz
echo "Downloading Complete"

# Unzip Downloads
tar -xvzf oasis_cross-sectional_disc1.tar.gz
tar -xvzf oasis_cross-sectional_disc2.tar.gz
tar -xvzf oasis_cross-sectional_disc3.tar.gz
tar -xvzf oasis_cross-sectional_disc4.tar.gz
tar -xvzf oasis_cross-sectional_disc5.tar.gz
tar -xvzf oasis_cross-sectional_disc6.tar.gz
tar -xvzf oasis_cross-sectional_disc7.tar.gz
tar -xvzf oasis_cross-sectional_disc8.tar.gz
tar -xvzf oasis_cross-sectional_disc9.tar.gz
tar -xvzf oasis_cross-sectional_disc10.tar.gz
tar -xvzf oasis_cross-sectional_disc11.tar.gz
tar -xvzf oasis_cross-sectional_disc12.tar.gz

# Merge Directories
echo "Merging Directories"
rsync -avh --progress ./disc1/ ./disc2/ ./disc3/ ./disc4/ ./disc5/ ./disc6/ ./disc7/ ./disc8/ ./disc9/ ./disc10/ ./disc11/ ./disc12/

# Clean-Up
mv ./disc12/ ./Data/
rm -rf ./disc1/ ./disc2/ ./disc3/ ./disc4/ ./disc5/ ./disc6/ ./disc7/ ./disc8/ ./disc9/ ./disc10/ ./disc11/

echo "Complete!"
echo "Dataset located at ./Data"
