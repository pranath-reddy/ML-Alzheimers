"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 0: Dataset Sample Visualization (OASIS-2)
"""

# Import libraries
import numpy as np
import os
import nibabel as nib
import matplotlib.pyplot as plt
from skimage.transform import rescale
import matplotlib

# Normalize data
def norm(data):
    pixels = data[data > 0]
    mean = pixels.mean()
    std  = pixels.std()
    # Normalize
    out = (data - mean)/std
    return out

# Import Data
# OASIS1 Sample
data = nib.load("./Data/OASIS2/Data/OAS2_0001_MR1/RAW/mpr-1.nifti.img").get_fdata()
data = np.asarray(data)
# Reshape
data = data.reshape(256,256,128)
# Alternate Orientation
data2 = np.transpose(data, (1, 2, 0))
# Alternate Orientation
data3 = np.rot90(data, 3, axes=(1,2))

# Normalize Data
sample = norm(data)
sample2 = norm(data2)
sample3 = norm(data3)

print(sample.shape)
print(sample2.shape)
print(sample3.shape)

# Save samples
matplotlib.image.imsave('./Results/OAS2_sample.png', np.rot90(sample[:,:,64]), cmap='gray')
matplotlib.image.imsave('./Results/OAS2_sample2.png', np.flipud(sample2[:,:,128]), cmap='gray')
matplotlib.image.imsave('./Results/OAS2_sample3.png', np.flipud(sample3[:,:,128]), cmap='gray')
