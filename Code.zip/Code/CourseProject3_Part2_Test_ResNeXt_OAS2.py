"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 2: Test Classifier (ResNeXt-50)
"""

# Import libraries
import numpy as np
import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.autograd import Variable
from torchvision import models
from tqdm import tqdm
from sklearn.utils import shuffle
from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix

# Set seed
torch.manual_seed(36)
torch.cuda.manual_seed(36)
torch.cuda.manual_seed_all(36)
# Clear memory
torch.cuda.empty_cache()

# 2D ResNeXt-50 Model
torch.hub._validate_not_a_forked_repo=lambda a,b,c: True
model = torch.hub.load('pytorch/vision:v0.10.0', 'resnext50_32x4d', pretrained=True) # ResNeXt-50
model.conv1 = torch.nn.Conv2d(10, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
model.fc = nn.Linear(in_features=2048, out_features=2, bias=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

# Import Test Data
x_val = np.load('./Data/OASIS2/oasis2_test_data.npy', allow_pickle=True).reshape(-1,256,256,10)
x_val = x_val.astype(np.float32)
y_val = np.load('./Data/OASIS2/oasis2_test_labels.npy', allow_pickle=True)
y_val = y_val.astype(np.float32)

# Split into batches
batch_size = 5
a = 0
b = batch_size
data_temp = []
data_temp2 = []
for i in range(int(x_val.shape[0]/batch_size)):
    data_temp.append(x_val[a:b])
    data_temp2.append(y_val[a:b])
    a += batch_size
    b += batch_size
x_val = np.asarray(data_temp)
x_val = np.moveaxis(x_val, -1, 2)
y_val = np.asarray(data_temp2).reshape(-1,5)

# Print data shape
print('Data Shape:')
print(x_val.shape)
print(y_val.shape)

# Import Model Checkpoint
if torch.cuda.is_available():
    model = torch.load('./Weights/ResNeXt50_OAS2.pth')
else:
    model = torch.load('./Weights/ResNeXt50_OAS2.pth', map_location=torch.device('cpu'))

model.eval()
torch.no_grad()

Acc = 0
y_pred = []
for i in range(x_val.shape[0]):

  data_val = torch.from_numpy(x_val[i])
  if torch.cuda.is_available():
    data_val = data_val.cuda()
  labels_val = torch.tensor(y_val[i], dtype=torch.long, device=device)

  _, preds_val = torch.max(model(data_val).data, 1)
  y_pred.append(preds_val.cpu().detach().numpy())
  correct_val = (preds_val == labels_val).float().sum()
  val_acc = correct_val/data_val.shape[0]
  Acc += val_acc

print('Accuracy: ')
print(Acc.cpu().detach().numpy()/x_val.shape[0])

y_score = []
for i in range(x_val.shape[0]):
    sample = torch.from_numpy(x_val[i])
    if torch.cuda.is_available():
      sample = sample.cuda()
    y_score.append(torch.nn.functional.softmax(model(sample), dim=1).cpu().detach().numpy())
y_score = np.asarray(y_score)

temp = []
for i in range(y_score.shape[0]):
  for j in range(y_score[i].shape[0]):
    temp.append(y_score[i][j])
y_score = np.asarray(temp)

y_test = []
y_pr = []
for i in range(y_val.shape[0]):
  for j in range(y_val[i].shape[0]):
    y_test.append(y_val[i][j])
    y_pr.append(y_pred[i][j])
y_test = np.asarray(y_test)
y_pred = np.asarray(y_pr)

# Calculate and print evaluation metrics
fpr, tpr, thresholds = roc_curve(y_test, y_score[:,1])
roc_auc = auc(fpr, tpr)
print('AUC: ')
print(roc_auc)

confmat = np.asarray(confusion_matrix(y_test, y_pred))
print('Confusion Matrix: ')
print(confmat)
tp = confmat[0,0]
tn = confmat[1,1]
fp = confmat[0,1]
fn = confmat[1,0]

sens = tp/(tp+fn)
print('Sensitivity/Recall: ')
print(sens)
spec = tn/(tn+fp)
print('Specificity: ')
print(spec)
prec = tp/(tp+fp)
print('Precision: ')
print(prec)
f1 = (2*tp)/(2*tp+fp+fn)
print('F1: ')
print(f1)
