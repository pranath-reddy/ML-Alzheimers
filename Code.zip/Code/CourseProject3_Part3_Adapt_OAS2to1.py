"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 3: Adaptation Part (Source: OAS2, Target: OAS1)
"""

# Import libraries
import numpy as np
import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.autograd import Variable
from torchvision import models
from tqdm import tqdm
from sklearn.utils import shuffle
import torch.nn.functional as F

# Set seed
torch.manual_seed(36)
torch.cuda.manual_seed(36)
torch.cuda.manual_seed_all(36)
# Clear memory
torch.cuda.empty_cache()

# ADDA Disciminator
class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()

        self.restored = False

        self.layer = nn.Sequential(
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, 2)
        )

    def forward(self, input):
        out = self.layer(input)
        return out

# 2D ResNeXt-50 Model
torch.hub._validate_not_a_forked_repo=lambda a,b,c: True
model = torch.hub.load('pytorch/vision:v0.10.0', 'resnext50_32x4d', pretrained=True) # ResNeXt-50
model.conv1 = torch.nn.Conv2d(10, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
model.fc = nn.Linear(in_features=2048, out_features=256, bias=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
encoder = model.to(device)

class Classifier(nn.Module):

    def __init__(self):
        super(Classifier, self).__init__()
        self.fc2 = nn.Linear(256, 2)

    def forward(self, feat):
        out = F.dropout(F.relu(feat), training=self.training)
        out = self.fc2(out)
        return out

classifier = Classifier().to(device)

# Import Training Data
x_train1 = np.load('./Data/OASIS2/oasis2_train_data.npy', allow_pickle=True).reshape(-1,15,256,256,10)
x_train1 = np.moveaxis(x_train1, -1, 2)
x_train1 = x_train1.astype(np.float32)
x_train2 = np.load('./Data/OASIS1/oasis1_train_data.npy', allow_pickle=True).reshape(-1,15,256,256,10)
x_train2 = np.moveaxis(x_train2, -1, 2)
x_train2 = x_train2.astype(np.float32)

np.random.shuffle(x_train1)
x_train1 = x_train1[:x_train2.shape[0]]

# Print data shape
print('Data Shape:')
print(x_train1.shape)
print(x_train2.shape)

# Import Model Checkpoint
if torch.cuda.is_available():
    encoder = torch.load('./Weights/DA/ResNeXt_Encoder_2.pth')
    classifier = torch.load('./Weights/DA/ResNeXt_Classifier_2.pth')
else:
    encoder = torch.load('./Weights/DA/ResNeXt_Encoder_2.pth', map_location=torch.device('cpu'))
    classifier = torch.load('./Weights/DA/ResNeXt_Classifier_2.pth', map_location=torch.device('cpu'))

src_encoder = encoder
tgt_encoder = encoder
critic = Discriminator().to(device)

# Loss Function
criterion = nn.CrossEntropyLoss()

# Optimizer
optimizer_tgt = optim.Adam(tgt_encoder.parameters(), lr=1e-6, betas=(0.5, 0.999), weight_decay=2.5e-5)
optimizer_critic = optim.Adam(critic.parameters(), lr=1e-5, betas=(0.5, 0.999), weight_decay=2.5e-5)

# Number of epochs
n_epochs = 20

# Training
print('Training!')
pbar = tqdm(range(1, n_epochs+1))
for epoch in pbar:

    for i in range(x_train1.shape[0]):

      images_src = torch.from_numpy(x_train1[i])
      images_tgt = torch.from_numpy(x_train2[i])
      if torch.cuda.is_available():
        images_src = images_src.cuda()
        images_tgt = images_tgt.cuda()

      # train Discriminator
      D_input_source = src_encoder(images_src)
      D_input_target = tgt_encoder(images_tgt)
      D_target_source = torch.tensor([0] * images_src.size(0), dtype=torch.long).to(device)
      D_target_target = torch.tensor([1] * images_tgt.size(0), dtype=torch.long).to(device)

      D_output_source = critic(D_input_source)
      D_output_target = critic(D_input_target)
      D_output = torch.cat([D_output_source, D_output_target], dim=0)
      D_target = torch.cat([D_target_source, D_target_target], dim=0)
      d_loss = criterion(D_output, D_target)
      optimizer_critic.zero_grad()
      d_loss.backward()
      optimizer_critic.step()

      # train Target
      D_input_target = tgt_encoder(images_tgt)
      D_output_target = critic(D_input_target)
      loss = criterion(D_output_target, D_target_source)
      optimizer_tgt.zero_grad()
      loss.backward()
      optimizer_tgt.step()

    pbar.set_postfix({ 'Critic Loss': d_loss.detach().cpu().numpy(), 'Tgt Loss': loss.detach().cpu().numpy() })
    torch.save(tgt_encoder, './Weights/DA/ResNeXt_Encoder_1_Adapted.pth')
