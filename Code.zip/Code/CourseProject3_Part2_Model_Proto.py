"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 2: Model Prototyping
"""

# Import libraries
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from torchsummary import summary
from torch.autograd import Variable
from torchvision import models
'''
## EfficientNet Implementation taken from:
## https://github.com/lukemelas/EfficientNet-PyTorch
'''
from efficientnet_pytorch import EfficientNet
'''
## 3D-ResNet Implementation taken from MedicalNet:
https://github.com/Tencent/MedicalNet
'''
import resnet3d

# 2D ResNet-18 Model
model_ft = models.resnet18(pretrained=True)
model_ft.conv1 = torch.nn.Conv2d(10, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
num_ftrs = model_ft.fc.in_features
model_ft.fc = nn.Sequential(nn.Dropout(0.5), nn.Linear(num_ftrs, 2))
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model_ft.to(device)

# Print Model architecture
print(model)
# Print
summary(model, (10,256,256))

# 2D EffNet-B3 Model
model = EfficientNet.from_pretrained('efficientnet-b3')
model._conv_stem = nn.Conv2d(10, 40, kernel_size=(3, 3), stride=(2, 2))
model._fc = nn.Linear(in_features=1536, out_features=2, bias=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

# Print Model architecture
print(model)
# Print
summary(model, (10,256,256))

# 2D ResNeXt-50 Model
model = torch.hub.load('pytorch/vision:v0.10.0', 'resnext50_32x4d', pretrained=True)
model.conv1 = torch.nn.Conv2d(10, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
model.fc = nn.Linear(in_features=2048, out_features=2, bias=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

# Print Model architecture
print(model)
# Print
summary(model, (10,256,256))

# 3D ResNet-18 Model
resnet_model = resnet3d.resnet18(sample_input_D=10, sample_input_H=256, sample_input_W=256, num_seg_classes=16)
classifier_model = resnet3d.Classifier()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
encoder = resnet_model.to(device)
classifier = classifier_model.to(device)

# Print Model architecture
print(encoder)
print(classifier)
# Print
summary(encoder, (1,256,256,10))
summary(classifier, (16,64,64,4))
