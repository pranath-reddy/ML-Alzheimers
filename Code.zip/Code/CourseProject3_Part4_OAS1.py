"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 1: Dataset Processing DG/AD (OASIS-1)
"""

# Import libraries
import numpy as np
import pandas as pd
import os
import nibabel as nib
from sklearn.utils import shuffle
from tqdm import tqdm

# Normalize data
def norm(data):
    pixels = data[data > 0]
    mean = pixels.mean()
    std  = pixels.std()
    # Normalize
    out = (data - mean)/std
    return out

# Import demographics data
df = pd.read_csv('./oasis_cross-sectional.csv')

# Get ID column from demographics data
file_id = df['ID']
file_id = np.asarray(file_id)

# Get labels column from demographics data
labels = df['CDR']
labels = np.asarray(labels)

# Shuffle files
file_id, labels = shuffle(file_id, labels, random_state=0)

# Import and process MRI scans of subjects
x_CN = []
x_AD = []
dem_count = 0
non_dem_count = 0
pbar = tqdm(range(labels.shape[0]))
for i in pbar:

    if labels[i] == 0: # Normal
        non_dem_count += 1
        mypath = './Data/OASIS1/Data/' + file_id[i] + '/RAW'
        files = [os.path.join(mypath, f) for f in os.listdir(mypath) if f.endswith(".img")]
        files = np.asarray(files)
        for j in range(files.shape[0]):
            data = nib.load(files[j]).get_fdata()
            data = np.asarray(data)
            # Normalize
            data = norm(data)
            # Slice data
            data = data[:,:,0:128:13]
            data = data.reshape(1,256,256,10)
            x_CN.append(data)

    elif labels[i] == (0.5 or 1 or 2): # Demented
        dem_count += 1
        mypath = './Data/OASIS1/Data/' + file_id[i] + '/RAW'
        files = [os.path.join(mypath, f) for f in os.listdir(mypath) if f.endswith(".img")]
        files = np.asarray(files)
        for j in range(files.shape[0]):
            data = nib.load(files[j]).get_fdata()
            data = np.asarray(data)
            # Normalize
            data = norm(data)
            # Slice data
            data = data[:,:,0:128:13]
            data = data.reshape(1,256,256,10)
            x_AD.append(data)

    pbar.set_postfix({ 'Processed Subject ': i+1, 'Total Subjects ': labels.shape[0] })

print('Total Normal Subjects: ' + str(non_dem_count))
print('Total Demented Subjects: ' + str(dem_count))

#Convert to NumPy arrays and print data size
print('Processed data size: ')
x_CN = np.asarray(x_CN)
print(x_CN.shape)
x_AD = np.asarray(x_AD)
print(x_AD.shape)

# Split into train and test sets
Split = 0.8
x_CN_train, x_CN_test, x_AD_train, x_AD_test = x_CN[:int(x_CN.shape[0]*Split)], x_CN[int(x_CN.shape[0]*Split):], x_AD[:int(x_AD.shape[0]*Split)], x_AD[int(x_AD.shape[0]*Split):]

# Clear memory
del x_CN
del x_AD

# Split into batches
batch_size = 30
a = 0
b = batch_size
data_temp = []
for i in range(int(x_CN_train.shape[0]/batch_size)):
    data_temp.append(x_CN_train[a:b])
    a += batch_size
    b += batch_size
x_CN_train = np.asarray(data_temp)
a = 0
b = batch_size
data_temp = []
for i in range(int(x_AD_train.shape[0]/batch_size)):
    data_temp.append(x_AD_train[a:b])
    a += batch_size
    b += batch_size
x_AD_train = np.asarray(data_temp)

# Print data size
print('Final data size: ')
print(x_CN_train.shape)
print(x_AD_train.shape)
print(x_CN_test.shape)
print(x_AD_test.shape)

# Save arrays
np.save('./Data/OASIS1/oasis1_train_CN.npy', x_CN_train)
np.save('./Data/OASIS1/oasis1_train_AD.npy', x_AD_train)
np.save('./Data/OASIS1/oasis1_test_CN.npy', x_CN_test)
np.save('./Data/OASIS1/oasis1_test_AD.npy', x_AD_test)
