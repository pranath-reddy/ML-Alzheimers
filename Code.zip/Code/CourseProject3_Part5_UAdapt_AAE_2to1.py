"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 5: (ADDA Domain Adaptation) Adversarial Autoencoder
"""

# Import libraries
import numpy as np
import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.autograd import Variable
from torchvision import models
from tqdm import tqdm
from sklearn.utils import shuffle
import torch.nn.functional as F
from torch import autograd

# Set seed
torch.manual_seed(36)
torch.cuda.manual_seed(36)
torch.cuda.manual_seed_all(36)
# Clear memory
torch.cuda.empty_cache()

# Model
class Encoder(nn.Module):

    def __init__(self):
        super().__init__()

        self.conv1 = nn.Conv2d(10, 16, (7,7), stride = 2)
        self.conv2 = nn.Conv2d(16, 32, (7,7), stride = 2)
        self.conv3 = nn.Conv2d(32, 64, (7,7))
        self.pool = nn.AvgPool2d(2, 2)
        self.flat = nn.Flatten()
        self.linear = nn.Linear(4096, 512)
        self.BN = nn.BatchNorm1d(512)

    def forward(self, x):

        convolution1 = self.pool(F.relu(self.conv1(x)))
        convolution2 = self.pool(F.relu(self.conv2(convolution1)))
        convolution3 = F.relu(self.conv3(convolution2))
        Flattened = self.flat(convolution3)
        z = self.linear(Flattened)

        return z

class Discriminator(nn.Module):
    def __init__(self):
        super(Discriminator, self).__init__()

        self.restored = False

        self.layer = nn.Sequential(
            nn.Linear(512, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, 2)
        )

    def forward(self, input):
        out = self.layer(input)
        return out

# Import Data
x_train1 = np.load('./Data/OASIS2/oasis2_train_CN.npy').reshape(-1,15,256,256,10)
x_train1 = np.moveaxis(x_train1, -1, 2)
x_train1 = x_train1.astype(np.float32)
x_train2 = np.load('./Data/OASIS1/oasis1_train_data.npy').reshape(-1,15,256,256,10)
x_train2 = np.moveaxis(x_train2, -1, 2)
x_train2 = x_train2.astype(np.float32)

np.random.shuffle(x_train1)
np.random.shuffle(x_train2)
x_train2 = x_train2[:x_train1.shape[0]]
print(x_train1.shape)
print(x_train2.shape)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
encoder = Encoder().to(device)

# Import Model Checkpoint
if torch.cuda.is_available():
    encoder = torch.load('./Weights/AAE_Enc_OAS2_CN.pth')
else:
    encoder = torch.load('./Weights/AAE_Enc_OAS2_CN.pth', map_location=torch.device('cpu'))

src_encoder = encoder
tgt_encoder = encoder
critic = Discriminator().to(device)

criterion = nn.CrossEntropyLoss()

optimizer_tgt = optim.Adam(tgt_encoder.parameters(), lr=1e-6, betas=(0.5, 0.999), weight_decay=2.5e-5)
optimizer_critic = optim.Adam(critic.parameters(), lr=1e-5, betas=(0.5, 0.999), weight_decay=2.5e-5)

n_epochs = 500

pbar = tqdm(range(1, n_epochs+1))
for epoch in pbar:

  for i in range(x_train1.shape[0]):

      images_src = torch.from_numpy(x_train1[i])
      images_tgt = torch.from_numpy(x_train2[i])
      if torch.cuda.is_available():
        images_src = images_src.cuda()
        images_tgt = images_tgt.cuda()

      # train Discriminator
      D_input_source = src_encoder(images_src)
      D_input_target = tgt_encoder(images_tgt)
      D_target_source = torch.tensor([0] * images_src.size(0), dtype=torch.long).to(device)
      D_target_target = torch.tensor([1] * images_tgt.size(0), dtype=torch.long).to(device)

      D_output_source = critic(D_input_source)
      D_output_target = critic(D_input_target)
      D_output = torch.cat([D_output_source, D_output_target], dim=0)
      D_target = torch.cat([D_target_source, D_target_target], dim=0)
      d_loss = criterion(D_output, D_target)
      optimizer_critic.zero_grad()
      d_loss.backward()
      optimizer_critic.step()

      # train Target
      D_input_target = tgt_encoder(images_tgt)
      D_output_target = critic(D_input_target)
      loss = criterion(D_output_target, D_target_source)
      optimizer_tgt.zero_grad()
      loss.backward()
      optimizer_tgt.step()

  # Print stats
  pbar.set_postfix({ 'Critic Loss': d_loss.detach().cpu().numpy(), 'Tgt Loss': loss.detach().cpu().numpy() })

  torch.save(tgt_encoder, './Weights/AAE_Enc_OAS1_CN_UDA.pth')
