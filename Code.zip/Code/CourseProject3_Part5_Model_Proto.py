"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 2: Model Prototyping
"""

# Import libraries
import torch
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
from torchsummary import summary
from torch.autograd import Variable
from torchvision import models

# Model 1
# Autoencoder for feature extraction
class Autoencoder(nn.Module):
    def __init__(self):
        super(Autoencoder, self).__init__()

        self.encoder = nn.Sequential(
            nn.Conv2d(10, 16, (7,7), stride = 2),
            nn.RReLU(),
            nn.AvgPool2d(2, 2),
            nn.Conv2d(16, 32, (7,7), stride = 2),
            nn.RReLU(),
            nn.AvgPool2d(2, 2),
            nn.Conv2d(32, 64, (7,7)),
            nn.RReLU(),
            nn.Flatten(),
            nn.Linear(4096, 512),
            nn.BatchNorm1d(512),
            nn.Linear(512, 4096)
        )

        self.decoder = nn.Sequential(
            nn.ConvTranspose2d(64, 32, (7,7)),
            nn.RReLU(),
            nn.Upsample(scale_factor=2),
            nn.ConvTranspose2d(32, 16, (7,7), stride = 2, output_padding=(1,1)),
            nn.RReLU(),
            nn.Upsample(scale_factor=2),
            nn.ConvTranspose2d(16, 10, (9,9), stride = 2, output_padding=(1,1)),
            nn.Tanh()
        )

    def forward(self, x):
        x = self.encoder(x)
        x = x.reshape(-1,64,8,8)
        x = self.decoder(x)
        return x

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = Autoencoder().to(device)

# Print Model architecture
print(model)
# Print
summary(model, (10,256,256))
