"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 3: Train Encoder and Classifier for Domain Adaptation (Source: OAS2, Target: OAS1)
"""

# Import libraries
import numpy as np
import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.autograd import Variable
from torchvision import models
from tqdm import tqdm
from sklearn.utils import shuffle
import torch.nn.functional as F

# Set seed
torch.manual_seed(36)
torch.cuda.manual_seed(36)
torch.cuda.manual_seed_all(36)
# Clear memory
torch.cuda.empty_cache()

# 2D ResNeXt-50 Model
torch.hub._validate_not_a_forked_repo=lambda a,b,c: True
model = torch.hub.load('pytorch/vision:v0.10.0', 'resnext50_32x4d', pretrained=True) # ResNeXt-50
model.conv1 = torch.nn.Conv2d(10, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
model.fc = nn.Linear(in_features=2048, out_features=256, bias=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
encoder = model.to(device)

class Classifier(nn.Module):

    def __init__(self):
        super(Classifier, self).__init__()
        self.fc2 = nn.Linear(256, 2)

    def forward(self, feat):
        out = F.dropout(F.relu(feat), training=self.training)
        out = self.fc2(out)
        return out

classifier = Classifier().to(device)

# Import Training Data
x_train = np.load('./Data/OASIS2/oasis2_train_data.npy', allow_pickle=True).reshape(-1,30,256,256,10)
x_train = np.moveaxis(x_train, -1, 2)
x_train = x_train.astype(np.float32)
y_train = np.load('./Data/OASIS2/oasis2_train_labels.npy', allow_pickle=True).reshape(-1,30)
y_train = y_train.astype(np.float32)

# Print data shape
print('Data Shape:')
print(x_train.shape)
print(y_train.shape)

# Loss Function
criteria = nn.CrossEntropyLoss()

# Optimizer
optimizer = torch.optim.Adam(list(encoder.parameters()) + list(classifier.parameters()), lr=2e-4, weight_decay=1e-5)

# Number of epochs
n_epochs = 50

# Training
print('Training!')
loss_array = []
for epoch in range(1, n_epochs+1):
    train_loss = 0.0
    train_acc = 0.0

    for i in tqdm(range(x_train.shape[0])):

        data = torch.from_numpy(x_train[i])
        if torch.cuda.is_available():
          data = data.cuda()
        labels = torch.tensor(y_train[i], dtype=torch.long, device=device)
        optimizer.zero_grad()
        outputs = classifier(encoder(data))
        _, preds = torch.max(classifier(encoder(data)).data, 1)
        correct = (preds == labels).float().sum()
        loss = criteria(outputs, labels)
        loss.backward()
        optimizer.step()

        train_loss += loss
        train_acc += correct/data.shape[0]

    train_loss = train_loss/x_train.shape[0]
    train_acc = train_acc/x_train.shape[0]
    loss_array.append(train_loss.cpu().detach().numpy())
    print('Epoch: {} \tTraining Loss: {:.6f} \tTraining Acc: {:.6f}'.format(epoch,train_loss,train_acc))
    print('')
    torch.save(encoder, './Weights/DA/ResNeXt_Encoder_2.pth')
    torch.save(classifier, './Weights/DA/ResNeXt_Classifier_2.pth')
    np.save('./Results/ResNeXt_OAS2_DA_Loss', loss_array)
