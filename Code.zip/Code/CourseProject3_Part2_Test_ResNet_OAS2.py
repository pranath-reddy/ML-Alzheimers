"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 2: Test Classifier
"""

# Import libraries
import numpy as np
import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.autograd import Variable
from torchvision import models
from tqdm import tqdm
from sklearn.utils import shuffle
from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt

# Set seed
torch.manual_seed(36)
torch.cuda.manual_seed(36)
torch.cuda.manual_seed_all(36)
# Clear memory
torch.cuda.empty_cache()

# 2D ResNet-18 Model
model_ft = models.resnet18(pretrained=True)
model_ft.conv1 = torch.nn.Conv2d(10, 64, kernel_size=(7, 7), stride=(2, 2), padding=(3, 3), bias=False)
num_ftrs = model_ft.fc.in_features
model_ft.fc = nn.Sequential(nn.Dropout(0.5), nn.Linear(num_ftrs, 2))
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model_ft.to(device)

# Import Test Data
x_val = np.load('./Data/OASIS2/oasis2_test_data.npy', allow_pickle=True).reshape(-1,256,256,10)
x_val = x_val.astype(np.float32)
y_val = np.load('./Data/OASIS2/oasis2_test_labels.npy', allow_pickle=True)
y_val = y_val.astype(np.float32)

# Split into batches
batch_size = 5
a = 0
b = batch_size
data_temp = []
data_temp2 = []
for i in range(int(x_val.shape[0]/batch_size)):
    data_temp.append(x_val[a:b])
    data_temp2.append(y_val[a:b])
    a += batch_size
    b += batch_size
x_val = np.asarray(data_temp)
x_val = np.moveaxis(x_val, -1, 2)
y_val = np.asarray(data_temp2).reshape(-1,5)

# Print data shape
print('Data Shape:')
print(x_val.shape)
print(y_val.shape)

# Import Model Checkpoint
if torch.cuda.is_available():
    model = torch.load('./Weights/ResNet18_OAS2.pth')
else:
    model = torch.load('./Weights/ResNet18_OAS2.pth', map_location=torch.device('cpu'))

model.eval()
torch.no_grad()

Acc = 0
for i in range(x_val.shape[0]):

  data_val = torch.from_numpy(x_val[i])
  if torch.cuda.is_available():
    data_val = data_val.cuda()
  labels_val = torch.tensor(y_val[i], dtype=torch.long, device=device)

  _, preds_val = torch.max(model(data_val).data, 1)
  correct_val = (preds_val == labels_val).float().sum()
  val_acc = correct_val/data_val.shape[0]
  Acc += val_acc

print('Accuracy: ')
print(Acc.cpu().detach().numpy()/x_val.shape[0])
