"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 1: Dataset Processing (OASIS-1)
"""

# Import libraries
import numpy as np
import pandas as pd
import os
import nibabel as nib
from sklearn.utils import shuffle
from tqdm import tqdm

# Normalize data
def norm(data):
    pixels = data[data > 0]
    mean = pixels.mean()
    std  = pixels.std()
    # Normalize
    out = (data - mean)/std
    # Add Noise to background
    out_random = np.random.normal(0, 1, size = data.shape)
    out[data == 0] = out_random[data == 0]
    return out

# Import demographics data
df = pd.read_csv('./oasis_cross-sectional.csv')

# Get ID column from demographics data
file_id = df['ID']
file_id = np.asarray(file_id)

# Get labels column from demographics data
labels = df['CDR']
labels = np.asarray(labels)

# Shuffle files
file_id, labels = shuffle(file_id, labels, random_state=0)

# Import and process MRI scans of subjects
x = []
y = []
dem_count = 0
non_dem_count = 0
pbar = tqdm(range(labels.shape[0]))
for i in pbar:

    if labels[i] == 0: # Normal
        non_dem_count += 1
        mypath = './Data/OASIS1/Data/' + file_id[i] + '/RAW'
        files = [os.path.join(mypath, f) for f in os.listdir(mypath) if f.endswith(".img")]
        files = np.asarray(files)
        for j in range(files.shape[0]):
            data = nib.load(files[j]).get_fdata()
            data = np.asarray(data)
            # Normalize
            data = norm(data)
            # Slice data
            data = data[:,:,0:128:13]
            data = data.reshape(1,256,256,10)
            x.append(data)
            y.append([0])

    elif labels[i] == (0.5 or 1 or 2): # Demented
        dem_count += 1
        mypath = './Data/OASIS1/Data/' + file_id[i] + '/RAW'
        files = [os.path.join(mypath, f) for f in os.listdir(mypath) if f.endswith(".img")]
        files = np.asarray(files)
        for j in range(files.shape[0]):
            data = nib.load(files[j]).get_fdata()
            data = np.asarray(data)
            # Normalize
            data = norm(data)
            # Slice data
            data = data[:,:,0:128:13]
            data = data.reshape(1,256,256,10)
            x.append(data)
            y.append([1])

    pbar.set_postfix({ 'Processed Subject ': i+1, 'Total Subjects ': labels.shape[0] })

print('Total Normal Subjects: ' + str(non_dem_count))
print('Total Demented Subjects: ' + str(dem_count))

#Convert to NumPy arrays and print data size
print('Processed data size: ')
x = np.asarray(x)
print(x.shape)
y = np.asarray(y)
print(y.shape)

# Split into train and test sets
Split = 0.8
x_train, x_test, y_train, y_test = x[:int(x.shape[0]*Split)], x[int(x.shape[0]*Split):], y[:int(y.shape[0]*Split)], y[int(y.shape[0]*Split):]

# Shuffle data
x_train, y_train = shuffle(x_train, y_train, random_state=0)
x_test, y_test = shuffle(x_test, y_test, random_state=0)

# Clear memory
del x
del y

# Split into batches
batch_size = 30
a = 0
b = batch_size
data_temp = []
data_temp2 = []
for i in range(int(x_train.shape[0]/batch_size)):
    data_temp.append(x_train[a:b])
    data_temp2.append(y_train[a:b])
    a += batch_size
    b += batch_size
x_train = np.asarray(data_temp)
y_train = np.asarray(data_temp2)

# Print data size
print('Final data size: ')
print(x_train.shape)
print(y_train.shape)
print(x_test.shape)
print(y_test.shape)

# Save arrays
np.save('./Data/OASIS1/oasis1_train_data.npy', x_train)
np.save('./Data/OASIS1/oasis1_train_labels.npy', y_train)
np.save('./Data/OASIS1/oasis1_test_data.npy', x_test)
np.save('./Data/OASIS1/oasis1_test_labels.npy', y_test)
