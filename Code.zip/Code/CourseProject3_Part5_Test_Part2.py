"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 5: AAE, VAE - Post-Training AUC score and distribution
"""

import numpy as np
from tqdm import tqdm
import pandas as pd
from sklearn.metrics import precision_recall_curve
from sklearn.utils import shuffle
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc, roc_auc_score
import math
import seaborn as sns
sns.set()

# Load loss reconstruction loss vectors
#losses1 = np.load('./Results/AD/VAE_CN_test_OAS1_recon_losses_2to1_NoDA.npy')
#losses2 = np.load('./Results/AD/VAE_AD_test_OAS1_recon_losses_2to1_NoDA.npy')

losses1 = np.load('./Results/AD/VAE_CN_test_OAS1_recon_losses.npy')
losses2 = np.load('./Results/AD/VAE_AD_test_OAS1_recon_losses.npy')

# Plot the distribution of reconstruction loss
w = 0.008
n1 = math.ceil((losses1.max() - losses1.min())/w)
n2 = math.ceil((losses2.max() - losses2.min())/w)

sns.distplot(losses2,label='AD',kde=0,norm_hist=0, color="r", bins=n2)
sns.distplot(losses1,label='CN',kde=0,norm_hist=0, color="g", bins=n1)
plt.legend()
plt.xlabel('MSELoss')
plt.ylabel('Population')
plt.title('Distribution of Reconstruction Loss for test samples')
plt.show()

y_ts1 = []
for i in range(losses1.shape[0]):
    y_ts1.append(0)
y_ts1 = np.asarray(y_ts1)
y_ts2 = []
for i in range(losses2.shape[0]):
    y_ts2.append(1)
y_ts2 = np.asarray(y_ts2)

x_ts = np.concatenate((losses1,losses2)).reshape(-1,1)
y_ts = np.concatenate((y_ts1,y_ts2))

# Calculate AUC
fpr, tpr, thresholds = roc_curve(y_ts, x_ts)
roc_auc = auc(fpr, tpr)

result = {'fpr' : np.array(fpr), 'tpr': np.array(tpr)}
#np.save('./Results/ROC/VAE_2to1_NoDA_roc.npy',  result)
np.save('./Results/ROC/VAE_AD_OAS1_roc.npy',  result)

# Plot the AUC
plt.figure()
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.5f)' % roc_auc)
plt.plot([0, 1], [0, 1], 'k--', lw=2)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve for Binary Classification')
plt.legend(loc="lower right", prop={"size":10})
plt.show()

print('ROC Values have been saved!')
