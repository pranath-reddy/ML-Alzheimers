"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 5: Post-Training Adversarial Autoencoder
"""

import torch
import numpy as np
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.autograd import Variable
from tqdm import tqdm
from torch import autograd

# Set seed
torch.manual_seed(36)
torch.cuda.manual_seed(36)
torch.cuda.manual_seed_all(36)
# Clear memory
torch.cuda.empty_cache()

# Model
class Encoder(nn.Module):

    def __init__(self):
        super().__init__()

        self.conv1 = nn.Conv2d(10, 16, (7,7), stride = 2)
        self.conv2 = nn.Conv2d(16, 32, (7,7), stride = 2)
        self.conv3 = nn.Conv2d(32, 64, (7,7))
        self.pool = nn.AvgPool2d(2, 2)
        self.flat = nn.Flatten()
        self.linear = nn.Linear(4096, 512)
        self.BN = nn.BatchNorm1d(512)

    def forward(self, x):

        convolution1 = self.pool(F.relu(self.conv1(x)))
        convolution2 = self.pool(F.relu(self.conv2(convolution1)))
        convolution3 = F.relu(self.conv3(convolution2))
        Flattened = self.flat(convolution3)
        z = self.linear(Flattened)

        return z

class Decoder(nn.Module):

    def __init__(self):
        super().__init__()

        self.linear = nn.Linear(512, 4096)
        self.upsample = nn.Upsample(scale_factor=2)
        self.conv4 = nn.ConvTranspose2d(64, 32, (7,7))
        self.conv5 = nn.ConvTranspose2d(32, 16, (7,7), stride = 2, output_padding=(1,1))
        self.conv6 = nn.ConvTranspose2d(16, 10, (9,9), stride = 2, output_padding=(1,1))

    def forward(self, x):

        hidden = self.linear(x)
        Reshaped = hidden.reshape(-1,64,8,8)
        convolution4 = self.upsample(F.relu(self.conv4(Reshaped)))
        convolution5 = self.upsample(F.relu(self.conv5(convolution4)))
        predicted = torch.tanh(self.conv6(convolution5))

        return predicted

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
encoder = Encoder().to(device)
decoder = Decoder().to(device)

# Import Model Checkpoint
if torch.cuda.is_available():
    encoder = torch.load('./Weights/AAE_Enc_OAS1_CN_UDA.pth', map_location=torch.device('cuda'))
    decoder = torch.load('./Weights/AAE_Dec_OAS2_CN.pth', map_location=torch.device('cuda'))
else:
    encoder = torch.load('./Weights/AAE_Enc_OAS1_CN_UDA.pth', map_location=torch.device('cpu'))
    decoder = torch.load('./Weights/AAE_Dec_OAS2_CN.pth', map_location=torch.device('cpu'))

# Import Test Data
x_train = np.load('./Data/OASIS1/oasis1_test_CN.npy').reshape(-1,256,256,10)
x_train = np.moveaxis(x_train, -1, 1)
x_train = x_train.astype(np.float32)

# Print data shape
print('Data Shape:')
print(x_train.shape)

out = []
for i in tqdm(range(x_train.shape[0])):

    data = torch.from_numpy(x_train[i].reshape(1,10,256,256))
    if torch.cuda.is_available():
      data = data.cuda()
    feature = encoder(data)
    recon = decoder(feature)
    out.append(recon.cpu().detach().numpy())

output = np.asarray(out).reshape(-1,10,256,256)
print('Size of reconstructed samples')
print(output.shape)
# Save reconstructed samples
np.save('./Results/AD/AAE_CN_test_OAS1_recon_2to1_UDA.npy',  output)
#np.save('./Results/AD/AAE_AD_test_OAS2_recon.npy',  output)

losses = []
for i in range(x_train.shape[0]):
    criteria = nn.MSELoss()
    losses.append(criteria(torch.from_numpy(x_train[i]), torch.from_numpy(output[i])))
losses = np.asarray(losses)
print('Size of loss vector')
print(losses.shape)
# Save reconstruction losses
np.save('./Results/AD/AAE_CN_test_OAS1_recon_losses_2to1_UDA.npy',  losses)
#np.save('./Results/AD/AAE_AD_test_OAS2_recon_losses.npy',  losses)
