"""
CAP 5404 Deep Learning for Computer Graphics
Project III

Pranath Reddy Kumbam (UFID: 8512-0977)

Part 2: Train Classifier (EfficientNet-B3)
"""

# Import libraries
import numpy as np
import os
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim import lr_scheduler
from torch.autograd import Variable
from torchvision import models
from tqdm import tqdm
from sklearn.utils import shuffle
'''
## EfficientNet Implementation taken from:
## https://github.com/lukemelas/EfficientNet-PyTorch
'''
from efficientnet_pytorch import EfficientNet

# Set seed
torch.manual_seed(36)
torch.cuda.manual_seed(36)
torch.cuda.manual_seed_all(36)
# Clear memory
torch.cuda.empty_cache()

# 2D EffNet-B3 Model
model = EfficientNet.from_pretrained('efficientnet-b3')
model._conv_stem = nn.Conv2d(10, 40, kernel_size=(3, 3), stride=(2, 2))
model._fc = nn.Linear(in_features=1536, out_features=2, bias=True)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

# Import Training Data
x_train = np.load('./Data/OASIS2/oasis2_train_data.npy', allow_pickle=True).reshape(-1,30,256,256,10)
x_train = np.moveaxis(x_train, -1, 2)
x_train = x_train.astype(np.float32)
y_train = np.load('./Data/OASIS2/oasis2_train_labels.npy', allow_pickle=True).reshape(-1,30)
y_train = y_train.astype(np.float32)

# Print data shape
print('Data Shape:')
print(x_train.shape)
print(y_train.shape)

'''
# Import Model Checkpoint
print('Importing Checkpoint')
if torch.cuda.is_available():
    model = torch.load('./Weights/EffNetB3_OAS2.pth')
else:
    model = torch.load('./Weights/EffNetB3_OAS2.pth', map_location=torch.device('cpu'))
'''

# Loss Function
criteria = nn.CrossEntropyLoss()

# Optimizer
optimizer = torch.optim.Adam(model.parameters(), lr=2e-4, weight_decay=1e-5)

# Number of epochs
n_epochs = 100

# Training
print('Training!')
loss_array = []
for epoch in range(1, n_epochs+1):
    train_loss = 0.0
    train_acc = 0.0

    for i in tqdm(range(x_train.shape[0])):

        data = torch.from_numpy(x_train[i])
        if torch.cuda.is_available():
          data = data.cuda()
        labels = torch.tensor(y_train[i], dtype=torch.long, device=device)
        optimizer.zero_grad()
        outputs = model(data)
        _, preds = torch.max(model(data).data, 1)
        correct = (preds == labels).float().sum()
        loss = criteria(outputs, labels)
        loss.backward()
        optimizer.step()

        train_loss += loss
        train_acc += correct/data.shape[0]

    train_loss = train_loss/x_train.shape[0]
    train_acc = train_acc/x_train.shape[0]
    loss_array.append(train_loss.cpu().detach().numpy())
    print('Epoch: {} \tTraining Loss: {:.6f} \tTraining Acc: {:.6f}'.format(epoch,train_loss,train_acc))
    print('')
    torch.save(model, './Weights/EffNetB3_OAS2.pth')
    np.save('./Results/EffNetB3_OAS2_Loss', loss_array)
